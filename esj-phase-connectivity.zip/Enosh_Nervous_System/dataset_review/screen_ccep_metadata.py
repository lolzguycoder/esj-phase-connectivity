#!/usr/bin/env python3
"""Public electrode-metadata feasibility screen; never downloads EEG waveforms."""
from pathlib import Path
import csv,io,json,hashlib,urllib.request
from concurrent.futures import ThreadPoolExecutor
ROOT=Path(__file__).resolve().parent
PREFIX='https://data.nemar.org/on004080/v1.0.0/'

def fetch(row):
    target=ROOT/'electrode_metadata'/row['path']
    target.parent.mkdir(parents=True,exist_ok=True)
    if not target.exists():
        with urllib.request.urlopen(PREFIX+row['path'],timeout=20) as response:
            target.write_bytes(response.read())
    data=target.read_bytes()
    records=list(csv.DictReader(io.StringIO(data.decode()),delimiter='\t'))
    hemisphere={r['hemisphere'] for r in records if r.get('hemisphere') in ['L','R']}
    # Anatomical feasibility proxy, not a validated PFC localization rule.
    frontal=[r for r in records if 'front' in r.get('Destrieux_label_text','').lower()]
    return {'path':row['path'],'sha256':hashlib.sha256(data).hexdigest(),'n_contacts':len(records),
            'hemispheres':sorted(hemisphere),'bilateral_metadata':hemisphere=={'L','R'},
            'frontal_label_contact_count':len(frontal),
            'frontal_label_hemispheres':sorted({r['hemisphere'] for r in frontal if r['hemisphere'] in ['L','R']})}

def run():
    manifest=json.loads((ROOT/'ccep_manifest.json').read_text())
    selected=[row for row in manifest if row['path'].endswith('electrodes.tsv')]
    successes=[];failures=[]
    def safe(row):
        try:return fetch(row)
        except Exception as e:return {'failed_path':row['path'],'error':type(e).__name__}
    with ThreadPoolExecutor(max_workers=8) as pool:
        for row in pool.map(safe,selected):
            (failures if 'failed_path' in row else successes).append(row)
    out={'retrieval_date':'2026-10-06','source':PREFIX,'dataset_version':'NEMAR v1.0.0; OpenNeuro source v1.2.4',
         'scope':'electrode metadata only; no waveform analysis, semantic content calibration, or validated PFC definition',
         'electrode_files_listed':len(selected),'electrode_files_downloaded':len(successes),'failures':failures,
         'bilateral_sessions':[r['path'] for r in successes if r['bilateral_metadata']],
         'frontal_label_files':sum(r['frontal_label_contact_count']>0 for r in successes),'records':successes}
    (ROOT/'ccep_metadata_screen.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({k:out[k] for k in ['electrode_files_listed','electrode_files_downloaded','failures','bilateral_sessions','frontal_label_files']},indent=2))

if __name__=='__main__':run()
