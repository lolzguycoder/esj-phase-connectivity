# Public data review for phase-gated interregional transfer

Reviewed 6 October 2026. This is a feasibility review and a downloaded-metadata screen. No neural waveform, spike train or behavioral trial was fitted to the model. The search did not establish a dataset meeting every joint requirement.

| Resource | Supported component | Important missing condition | Access / source |
|---|---|---|---|
| CCEP ECoG ds004080 | Controlled input timing, stimulation sites, anatomical electrode metadata; candidate direct and reciprocal response timing | Semantic content maps, calibrated receptive-gain intervention and behavioral readout are not established by these metadata | [NEMAR pinned mirror v1.0.0](https://www.nemar.org/dataset/on004080); [source OpenNeuro v1.2.4](https://doi.org/10.18112/openneuro.ds004080.v1.2.4) |
| Allen Visual Behavior Neuropixels | Simultaneous regional population features and LFP; stimulus and behavior alignment; possible held-out projection-to-decision analysis | Observational task does not supply the isolated two-source factorial or known arrival-phase intervention; documented design is not a bilateral PFC experiment | [Official access documentation](https://allensdk.readthedocs.io/en/latest/visual_behavior_neuropixels.html) |
| Allen Visual Coding Neuropixels | Timed stimulus content, simultaneous spikes and LFP; cross-validated transfer-support and lag analyses | No causal isolation of a direct map from shared visual input; no report-status feedback test established | [Official documentation](https://allensdk.readthedocs.io/en/stable/visual_coding_neuropixels.html) |
| F-TRACT | Derived interregional axonal/synaptic delay references under an explicit evoked-response model | Atlas estimates do not supply content or behavior, and must not be treated as raw identified conduction; verify access/license before download | [Project atlas](https://www.f-tract.eu/atlas/); [primary study](https://doi.org/10.1093/brain/awab362) |

## Strongest controlled-timing candidate actually screened

All 74 electrode tables in the ds004080 mirror were downloaded successfully. Only `sub-ccepAgeUMCU17/ses-1` has both L and R labels in its explicit hemisphere column. Its table contains 32 L-labeled contacts, 32 R-labeled contacts and 30 contacts with unavailable labels. Across all tables, 64 contain a label with the substring `front`. This substring screen is a feasibility proxy, not a validated definition of PFC. Missing hemisphere labels must not be interpreted as unilateral placement.

Participant 17 has one left `G_front_sup` contact, `IHvL3`, and no right frontal-name labels. Its public event table has 526 rows, including 525 electrical-stimulation events. Joining stimulation-pair names to electrode metadata yields 260 left-site and 265 right-site events. The left frontal-name contact occurs in pairs `IHvL2-IHvL3` and `IHvL3-IHvL4`. This is a concrete candidate for testing left frontal / contralateral cortical timing, subject to anatomical validation and waveform inspection. It does not establish a sampled bilateral PFC loop or communication of conscious contents.

The example event table for participant 1 has 517 rows, including 460 electrical-stimulation rows; onset, sample indices and stimulation parameters are present. Those fields support an explicit epoching protocol. No raw EEG was downloaded. Peak response latency must be separated from artifact, referencing, local synaptic processing and indirect routes; it is not automatically axonal conduction.

The public [source-study README](https://data.nemar.org/on004080/v1.0.0/README.md) identifies the clinical RESPect registry, BIDS organization and CC0 license. Cite [van Blooijs et al. (2023)](https://doi.org/10.1038/s41593-023-01272-0) if using the dataset. Metadata copies, source paths and SHA256 records are included here. The screen is reproducible with `python dataset_review/screen_ccep_metadata.py`, using cached public tables; it downloads metadata only when missing.

## Strongest content / behavioral candidate

Allen Visual Behavior Neuropixels is the preferred starting point for observational content-transfer and innovation-to-decision analysis. Use its [official manifest and metadata tutorial](https://allensdk.readthedocs.io/en/latest/_static/examples/nb/visual_behavior_neuropixels_data_access.html) to freeze a version before session selection. The documentation describes 153 released sessions, while its default abnormality-filtered table lists 103; record which inclusion rule is used. Per-probe LFP availability is explicit. The documentation records corrected LFP scaling in v0.5.0; use a corrected, pinned release. Example session `1044385384` is a metadata screening starting point, not a session chosen by favorable model results.

Predefine quality filters, train/test separation, stimulus balance, lag-selection data, behavioral exclusion rules and mouse-level uncertainty. Estimate encoding maps from stimulus-labeled training trials, test receiver projections on held-out trials, compare common-input and additive rivals, and estimate noise covariance on independent calibration data. A neural interaction becomes a sensitivity prediction only if its innovation is class-dependent and a specified readout accesses it. Hits/misses are outcomes, not consciousness labels.

## Why this is not full validation

The complete model needs independently calibrated content maps, both directed causal perturbations on the same pair, justified conduction-versus-processing separation, calibrated phase-gain probes, interaction contrasts and a frozen decision rule. The resources above supply complementary pieces. Different species and cohorts cannot be merged as if they were one calibrated causal loop. A useful next study starts with participant 17 for timing feasibility and Allen population recordings for held-out content geometry, then designs a combined intervention experiment. None of the inspected documentation establishes all requirements.

## Expanded search: 6 October 2026

| Resource | Best component match | Gap preventing an entire-paper test |
|---|---|---|
| [MacDowell et al. 2025 / Dryad](https://doi.org/10.5061/dryad.gxd2547x8) | Simultaneous regional spikes and cortical imaging, including frontal populations; cross-validated projection geometry | Spontaneous recordings do not provide independently timed reciprocal content perturbations or a receptive phase scan. Imaging resolution is unsuitable for interpreting millisecond conduction directly. |
| [Gonzalez et al. 2026 / DANDI 001695](https://dandiarchive.org/dandiset/001695/0.260319.2023) | Simultaneous hippocampal–cortical populations, spatial behavior and replay; conditional subspace estimation | Task/sleep differences are not the teaching intervention or isolated causal return experiment required here. |
| [Claar et al. 2023 / DANDI 000458](https://dandiarchive.org/dandiset/000458/0.230317.0039) | Controlled cortical input timing, EEG and Neuropixels, state-dependent evoked responses | Anesthesia/state contrast is not a calibrated content/readout contrast. No documented full two-band gain scan and independent basis-pair intervention. |
| [IBL Brain Wide Map](https://docs.internationalbrainlab.org/notebooks_external/data_release_brainwidemap.html) | Broad anatomical sampling, sensory choices and response times | Pooled brain coverage does not establish simultaneous sampling of every target pair; standard task data do not isolate directed reciprocal perturbations. |
| [Binish et al. 2026](https://doi.org/10.1038/s41593-026-02290-4) | Human PFC–M1 population subspaces and contextual actions: close anatomical/task precedent | Source data and example code are public; additional recordings are available upon request. It is not an unrestricted complete raw-data release or a causal two-band/echo experiment. |

DANDI version metadata for 000458 and 001695 were successfully retrieved from the public archive API and are included as JSON. They state OpenAccess and CC-BY-4.0. Their stable versions are recorded above; no NWB waveforms were downloaded or analyzed. The copied short GitHub README for the multiplexed-subspace figure repository is an access pointer, not a waveform inspection. The Dryad repository documents six simultaneous sessions from three mice and links processed electrophysiology files; the study's regression associations are explicitly not causal direction estimates.

The presence of a related published finding is neither independent validation of our equations nor proof of novelty. In particular, projection-based communication is already established research territory. The paper's candidate contribution is the joint identification/delivery/return/readout design, whose empirical incremental value remains untested.

## Minimal combined protocol

1. Calibrate anchored content maps and map uncertainty on separate data; choose receiver readouts before testing.
2. Select one pair with simultaneous populations and both directed perturbations. Verify onset artifacts and separately constrain processing.
3. Acquire two stationary carrier frequencies plus a held-out receptive scan on a known phase branch. Predict independent timing.
4. Apply sender content contrasts at matched input power and phase. Test the projected amplitude prediction on held-out items.
5. Resolve forward onset and subsequent return increments; change the reverse pathway while preserving the first forward input. Test the appropriate scalar or general stable-loop prediction.
6. If testing bilinear innovation, include both independently controlled inputs and all four factorial cells; estimate noise and complement rank using held-out basis pairs. Include an additive feedback baseline and joint-readout rival.
7. Test restricted teaching versus expanded teaching only if the target map and learning opportunity are independently operationalized.

None of the inspected resources documents all seven stages in the same preparation. Combining published outcomes from different cohorts cannot fill those design gaps.
